import Foundation

public enum DPITable {
  /// Sensor register indices recovered from Lenovo's M600 module. The sequence is
  /// not linear, especially above 15,100 DPI, so it must not be calculated.
  public static let values: [Int] = Array(stride(from: 100, through: 16_000, by: 100))

  public static let sensorIndices: [UInt16] = [
    0, 2, 3, 4, 5, 6, 7, 9, 10, 11, 12, 13, 14, 16, 17, 18,
    19, 20, 22, 23, 24, 25, 26, 27, 29, 30, 31, 32, 33, 35, 37, 38,
    39, 40, 41, 42, 44, 45, 46, 47, 48, 50, 51, 52, 53, 54, 56, 57,
    58, 59, 60, 62, 63, 64, 65, 66, 68, 69, 70, 71, 72, 74, 75, 76,
    77, 78, 80, 81, 82, 83, 84, 86, 87, 88, 89, 90, 92, 93, 94, 95,
    96, 98, 99, 100, 101, 102, 104, 105, 106, 107, 108, 110, 111, 112,
    113, 114, 116, 117, 118, 119, 120, 122, 123, 124, 125, 126, 128, 129,
    130, 131, 132, 134, 135, 136, 137, 138, 140, 141, 142, 143, 144, 146,
    147, 148, 149, 150, 152, 153, 154, 155, 156, 158, 159, 160, 161, 162,
    164, 165, 166, 167, 168, 170, 171, 172, 173, 174, 176, 177, 178, 179,
    180, 181, 182, 183, 184, 185, 186, 187, 188, 189,
  ]

  public static func sensorIndex(forDPI dpi: Int) -> UInt16? {
    guard dpi >= 100, dpi <= 16_000, dpi.isMultiple(of: 100) else { return nil }
    return sensorIndices[(dpi / 100) - 1]
  }

  public static func dpi(forSensorIndex index: UInt16) -> Int? {
    guard let position = sensorIndices.firstIndex(of: index) else { return nil }
    return values[position]
  }
}
